#pragma once
#include "DungeonObject.h"

class Pillar: public DungeonObject
{
public:
    Pillar(const char* filename, SDL_Renderer* ren, Position pos, Rectangle source, Rectangle dest): DungeonObject(filename, ren, pos, source, dest)
    {}
    virtual ~Pillar(){}

    void update();  //
    bool isCharacterHiding(Position characterPos);
};
