#pragma once
#include "DungeonObject.h"

class Haystack: public DungeonObject
{
public:
    Haystack(const char* filename, SDL_Renderer* ren, Position pos, Rectangle source, Rectangle dest): DungeonObject(filename, ren, pos, source, dest)
    {}
    virtual ~Haystack(){}
    bool isCharacterHiding(Position characterPos);
};

