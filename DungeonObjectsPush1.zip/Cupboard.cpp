#include "Cupboard.h"

bool Cupboard::isCharacterHiding(Position characterPos)
{
    return true;
}
