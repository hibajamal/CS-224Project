#pragma once

class Rectangle
{
public:
    int h, w;
    int x, y;
    Rectangle(int w, int h, int x, int y)
    {
        this->h = h;
        this->w = w;
        this->x = x;
        this->y = y;
    }
    virtual ~Rectangle(){}

    static Rectangle Set(int w, int h, int x, int y)
    {
        Rectangle rect(w, h, x, y);
        return rect;
    }
};
