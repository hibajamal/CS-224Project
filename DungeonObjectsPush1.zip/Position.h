#pragma once

class Position
{
public:
    Position(){}
    Position(int x, int y)
    {
        this->x = x;
        this->y = y;
    }
    ~Position(){}

    int x;  // x-axis position
    int y;  // y-axis position

    static Position Set(int x, int y)
    {
        Position pos(x,y);
        return pos;
    }
};
