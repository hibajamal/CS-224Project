#pragma once
#include "Game.h"

class Word
{
private:
    int x , y ;
    const char* renderWord;
    TextureManager* TxtTexture;
    Character* characters;
public:
    Word(){}
    Word ( const char* str , TextureManager* gSpriteSheetTexture,int x ,int y )
    {
        this->TxtTexture = gSpriteSheetTexture;
        setText ( str );
        setPosition (x , y );
    }
    void render ( SDL_Renderer* gRenderer )
    {
        for (int i = 0; i < getTextLength() i ++)
        {
        characters[i].render( gRenderer );
        }
    }
    void setText ( const char* str )
    {
        this - > x = x ;
        this - > y = y ;
        for (int i = 0; i < getTextLength(); i ++)
        {
        characters [ i ]. setPosition ( x + i *88 , y );
        }
    }
    void setPosition (int x ,int y )
    {
        this - > x = x ;
        this - > y = y ;
        for (int i = 0; i < getTextLength(); i ++)
        {
        characters [ i ]. setPosition ( x + i *88 , y );
        }
    }
    int getTextLength ()
    {
        int i = 0;
        while (renderWord[1] != '\0')
        {
            i++;
        }
        return i;
    }
};
