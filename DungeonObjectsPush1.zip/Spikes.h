#pragma once
#include "DungeonObject.h"

class Spikes:public DungeonObject
{
public:
    Spikes(const char* filename, SDL_Renderer* ren, Position pos, Rectangle source, Rectangle dest): DungeonObject(filename, ren, pos, source, dest)
    {}
    virtual ~Spikes(){}
    bool isCharacterHiding(Position characterPos);
};
