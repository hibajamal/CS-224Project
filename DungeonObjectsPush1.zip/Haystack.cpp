#include "Haystack.h"

bool Haystack::isCharacterHiding(Position pos)
{
    return true;
}

