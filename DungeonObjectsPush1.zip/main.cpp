#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include <iostream>
#include "Game.h"

Game* game = nullptr;

int main( int argc, char* args[] )
{
    game = new Game;
    game->init("New Game", Position::Set(SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED), 640, 480, false);

    while (game->running())
    {
        game->handleEvents();
        game->update();
        game->render();
    }

    game->clean();



    return 0;
}
