#include "Game.h"
#include "Pillar.h"
#include <iostream>

using namespace std;

DungeonObject* obj;

int countt;

void Game::init(const char* title, Position pos, int width, int height, bool fullscreen)
{
    int flags = 0;
    if (fullscreen)
    {
        flags = SDL_WINDOW_FULLSCREEN;
    }

    if (SDL_Init(SDL_INIT_EVERYTHING) == 0)
    {
        cout << "SDL INITIALIZED." << endl;
        window = SDL_CreateWindow(title, pos.x, pos.y, width, height, flags);
        if (window)
        {
            cout << "Window created." << endl;
        }

        renderer = SDL_CreateRenderer(window, -1, 0);
        if (renderer)
        {
            SDL_SetRenderDrawColor(renderer, 255, 255, 255, 5);
            cout << "Renderer created." << endl;
        }
        isRunning = true;
    }
    else
    {
        isRunning = false;
    }
    countt = 0;
    obj = new Pillar("download.png", renderer, Position::Set(0,0), Rectangle::Set(64, 64, 0, 0), Rectangle::Set(80, 80, 0, 0));
}

void Game::handleEvents()
{
    SDL_Event event;
    SDL_PollEvent(&event);

    switch (event.type)
    {
    case SDL_QUIT:
        isRunning = false;
        break;
    default:
        break;
    }
}

void Game::render()
{
    SDL_RenderClear(renderer);
    obj->render();
    SDL_RenderPresent(renderer);
}

void Game::update()
{
    obj->update();
}

void Game::clean()
{
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_Quit();
    cout << "All memory deallocated" << endl;
}
