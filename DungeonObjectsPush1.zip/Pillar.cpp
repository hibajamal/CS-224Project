#include "Pillar.h"

int time = 0;
Position x;

bool Pillar::isCharacterHiding(Position characterPos)
{
    return true;
}

void Pillar::update()
{
    time++;
    if (time % 20)
    {
        x = getPosition();
        x.x++;
        std::cout<<x.x<<endl;
        setPosition(x);
    }
}
