#pragma once
#include "Game.h"

class Drawers: public DungeonObject
{
public:
    Drawers(const char* filename, SDL_Renderer* ren, Position pos, Rectangle source, Rectangle dest): DungeonObject(filename, ren, pos, source, dest)
    {}
    virtual ~Drawers(){}
    void update();
    bool isCharacterInteracting(Position characterPos);
};
