#include "Torch.h"

bool Torch::isCharacterInteracting(Position pos)
{
    return true;
}

void Torch::update()
{
    //
}
