#include "DungeonObject.h"
#include <iostream>

using namespace std;

DungeonObject::DungeonObject(const char* filename, SDL_Renderer* ren, Position pos, Rectangle source, Rectangle dest)
{
    this->texture = TextureManager::LoadTexture(filename, ren);
    this->renderer = ren;
    this->pos = pos;

    //set rects
    sourceRect.h = source.h;
    sourceRect.w = source.w;
    sourceRect.x = source.x;
    sourceRect.y = source.y;

    destRect.h = dest.h;
    destRect.w = dest.w;
    destRect.x = dest.x;
    destRect.y = dest.y;
}

void DungeonObject::render()
{
    SDL_RenderCopy(renderer, texture, &sourceRect, &destRect);
}

SDL_Texture* DungeonObject::getTexture()
{
    return texture;
}

SDL_Rect DungeonObject::getSourceRect()
{
    return sourceRect;
}

SDL_Rect DungeonObject::getDestRect()
{
    return destRect;
}

SDL_Renderer* DungeonObject::getRenderer()
{
    return renderer;
}

Position DungeonObject::getPosition()
{
    return pos;
}

void DungeonObject::setPosition(Position p)
{
    this->pos = p;
    destRect.x = pos.x;
    destRect.y = pos.y;
}
