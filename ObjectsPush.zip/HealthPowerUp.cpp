#include "HealthPowerUp.h"

bool HealthPowerUp::isCharacterInteracting(Position pos)
{
    return true;
}

void HealthPowerUp::update()
{
    //
}
