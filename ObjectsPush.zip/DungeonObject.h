#pragma once
#include "Game.h"
#include "Rectangle.h"
#include <iostream>

// base class for dungeon objects
class DungeonObject
{
private:
    Position pos;

    SDL_Texture* texture;
    SDL_Rect sourceRect, destRect;
    SDL_Renderer* renderer;
public:
    DungeonObject(const char*, SDL_Renderer*, Position, Rectangle source, Rectangle dest);
    virtual ~DungeonObject(){}

    virtual void update() = 0;
    void render();
    virtual bool isCharacterInteracting(Position characterPos) = 0;   // check whether player is behind/inside object: will be different for different objects

    // Getters/Setters
    SDL_Texture* getTexture();
    SDL_Rect getSourceRect();
    SDL_Rect getDestRect();
    SDL_Renderer* getRenderer();
    Position getPosition();
    void setPosition(Position);
};
