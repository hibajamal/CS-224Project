#include "TextureManager.h"

SDL_Texture* TextureManager::LoadTexture(const char* filename, SDL_Renderer* renderer)
{
    SDL_Surface* tempSurface = IMG_Load(filename);
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, tempSurface);
    SDL_FreeSurface(tempSurface);

    return texture;
}

void TextureManager::render(int x, int y, SDL_Renderer* gRenderer, SDL_Rect* clip)
{
    SDL_Rect renderQuad = { x , y , width , height };
    if( clip != NULL )
    {
    renderQuad.w = clip->w ;
    renderQuad.h = clip->h ;
    }
    // Render to screen
    SDL_RenderCopy ( gRenderer , texture , clip , & renderQuad );
}
