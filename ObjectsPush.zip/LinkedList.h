#pragma once
#include "Node.h"

class LinkedList
{
private:
    Node* head;
    Node* tail;
    int index;
public:
    LinkedList();
    virtual ~LinkedList();

    Node* getHead();
    Node* getTail();
    void push(int index);
    int pop(int index);   // change return type with template
    int getSize();
    void show();
};
