#pragma once
#include "DungeonObject.h"

class Cupboard: public DungeonObject
{
private:
public:
    Cupboard(const char* filename, SDL_Renderer* ren, Position pos, Rectangle source, Rectangle dest): DungeonObject(filename, ren, pos, source, dest)
    {}
    virtual ~Cupboard(){}
    bool isCharacterHiding(Position characterPos);
};
