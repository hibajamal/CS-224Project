#pragma once
#include "Game.h"

class Traps: public DungeonObject
{
public:
    Traps(const char* filename, SDL_Renderer* ren, Position pos, Rectangle source, Rectangle dest): DungeonObject(filename, ren, pos, source, dest)
    {}
    virtual ~Traps(){}
    void update();
    bool isCharacterInteracting(Position characterPos);
};
