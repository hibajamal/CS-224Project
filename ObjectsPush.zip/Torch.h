#pragma once
#include "Game.h"

class Torch: public DungeonObject
{
public:
    Torch(const char* filename, SDL_Renderer* ren, Position pos, Rectangle source, Rectangle dest): DungeonObject(filename, ren, pos, source, dest)
    {}
    virtual ~Torch(){}
    void update();
    bool isCharacterInteracting(Position characterPos);
};
