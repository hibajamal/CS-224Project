#pragma once
#include "Game.h"

class Weapons: public DungeonObject
{
public:
    Weapons(const char* filename, SDL_Renderer* ren, Position pos, Rectangle source, Rectangle dest): DungeonObject(filename, ren, pos, source, dest)
    {}
    virtual ~Weapons(){}
    void update();
    bool isCharacterInteracting(Position characterPos);
};
