#include "Haystack.h"

bool Haystack::isCharacterInteracting(Position pos)
{
    return true;
}

