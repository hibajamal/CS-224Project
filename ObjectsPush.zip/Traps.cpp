#include "Traps.h"

bool Traps::isCharacterInteracting(Position pos)
{
    return true;
}

void Traps::update()
{
    //
}
