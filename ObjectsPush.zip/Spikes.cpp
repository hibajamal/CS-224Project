#include "Spikes.h"

bool Spikes::isCharacterHiding(Position characterPos)
{
    return true;
}
