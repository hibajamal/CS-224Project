#pragma once
#include "Game.h"

using namespace std;

class TextureManager
{
    int width, height;
    SDL_Texture* texture;
public:
    TextureManager(){}
    virtual ~TextureManager(){}

    static SDL_Texture* LoadTexture(const char*, SDL_Renderer*);
    void render (int x , int y , SDL_Renderer* gRenderer , SDL_Rect * clip = NULL );
};
