#pragma once
#include "DungeonObject.h"

class Keys: public DungeonObject
{
public:
    Keys(const char* filename, SDL_Renderer* ren, Position pos, Rectangle source, Rectangle dest): DungeonObject(filename, ren, pos, source, dest)
    {}
    virtual ~Keys(){}
    void update();
    bool isCharacterInteracting(Position characterPos);
};

