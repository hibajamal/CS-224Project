#include "Drawers.h"

bool Drawers::isCharacterInteracting(Position pos)
{
    return true;
}

void Drawers::update()
{
    //
}
